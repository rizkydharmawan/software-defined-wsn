#!/usr/bin/env bash

BASEDIR=$(dirname "$0")
cd $BASEDIR; cd ./../TinyOSComponents/; ./install.sh;
cd ../StringNetworkTest/;
cd ControllerExample/;
make clean;
make telosb;
cd SideControllerExample/;
make clean;
make telosb;
cd ../SensorNodeExample/;
make clean;
make telosb;
